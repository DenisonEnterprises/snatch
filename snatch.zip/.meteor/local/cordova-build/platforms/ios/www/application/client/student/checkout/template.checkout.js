(function(){
Template.__checkName("checkout");
Template["checkout"] = new Template("Template.checkout", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Checkout"), "\n  "), "\n    \n  \n  ", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "student");
  }, function() {
    return [ "\n\n\n   ", HTML.DIV({
      "class": "checkoutContainer"
    }, "\n    ", HTML.DIV({
      "class": "nav"
    }, "\n       ", HTML.UL("\n          ", HTML.LI(Blaze.View("lookup:currentUser.username", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "username"));
    })), "\n          ", HTML.LI({
      "class": "Settings"
    }, "\n            ", HTML.A({
      href: "/settings"
    }, "\n              ", HTML.IMG({
      src: "img/sm/settingsSM.png",
      alt: "Settings"
    }), "\n            "), "\n          "), "\n          \n          ", HTML.LI({
      "class": "Info"
    }, "\n            ", HTML.A({
      href: "/about"
    }, "\n              ", HTML.IMG({
      src: "img/sm/infoSM.png",
      alt: "Info"
    }), "\n            "), "\n          "), "\n          ", HTML.LI({
      "class": "Logout"
    }, " \n               ", HTML.BUTTON({
      "class": "logout",
      id: "logout"
    }, "Logout"), "\n          "), "\n          \n      "), "\n    "), " \n     \n     ", HTML.DIV({
      "class": "cout"
    }, "\n    \n \n  \n    ", HTML.H1("Checkout"), "\n       ", HTML.IMG({
      src: "img/checkTop.png",
      alt: "CheckTop"
    }), "\n  ", HTML.BR(), "\n\n      ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("order"));
    }, function() {
      return [ "\n       \n       ", HTML.DIV({
        "class": "line"
      }, "\n         \n         ", HTML.DIV({
        "class": "rmBtn"
      }, "\n           ", HTML.DIV({
        "class": "moveBtn"
      }, "\n             ", HTML.BUTTON({
        name: function() {
          return Spacebars.mustache(view.lookup("item"));
        },
        id: "deleteOrder",
        "class": "button-check"
      }, "X"), "\n           "), "\n         "), "\n         \n         ", HTML.DIV({
        "class": "itemz"
      }, "\n           ", HTML.DIV({
        "class": "moveItem"
      }, "\n           ", Blaze.View("lookup:item", function() {
        return Spacebars.mustache(view.lookup("item"));
      }), "\n           "), "\n         "), "\n         \n         ", HTML.DIV({
        "class": "price"
      }, "\n           ", HTML.DIV({
        "class": "movePrice"
      }, "\n          ", Blaze.View("lookup:price", function() {
        return Spacebars.mustache(view.lookup("price"));
      }), "\n           "), "\n         "), "\n        \n         ", HTML.BR(), "\n       "), "\n       \n       ", HTML.DIV({
        "class": "line"
      }, "\n         ", HTML.BR(), "\n       "), "\n       \n      \n       \n    " ];
    }), "\n       \n        ", HTML.DIV({
      "class": "line"
    }, "\n         ", HTML.BR(), "\n       "), "\n       \n       ", HTML.DIV({
      "class": "line"
    }, "\n         ", HTML.BR(), "\n       "), "\n       ", HTML.DIV({
      "class": "line"
    }, "\n         ", HTML.BR(), "\n       "), "\n       ", HTML.IMG({
      src: "img/checkBottom.png",
      alt: "CheckBottom"
    }), "\n ", HTML.BR(), "\n 	", HTML.H3(" There are ", Spacebars.include(view.lookupTemplate("orNum")), " Orders in front of yours. "), "\n 	", HTML.H3(" If you wish to cancel, click 'cancel'. Else, click 'Place Order' "), "\n 	", HTML.BUTTON({
      "class": "deleteOrder",
      id: "deleteOrder"
    }, " Cancel "), "\n    ", HTML.BUTTON({
      "class": "backBTN",
      id: "menu"
    }, "Menu"), "  \n    ", HTML.BUTTON({
      "class": "placeOrderBTN",
      id: "placeOrder"
    }, "Place Order"), "\n       ", HTML.BR(), "\n    ", HTML.BUTTON({
      "class": "goButton",
      id: "bagelBTN"
    }, "Bagels"), "\n    ", HTML.BUTTON({
      "class": "goButton",
      id: "shakesBTN"
    }, "Shakes"), "\n    ", HTML.BUTTON({
      "class": "bevBTN",
      id: "bevsBTN"
    }, "Beverages"), "\n    ", HTML.BUTTON({
      "class": "goButton",
      id: "snackBTN"
    }, "Snacks"), "\n       \n       \n\n       \n     "), "\n  "), "\n\n  \n    " ];
  }, function() {
    return [ "\n    \n     ", Spacebars.include(view.lookupTemplate("denied")), "\n  \n    " ];
  }) ];
}));

Template.__checkName("orNum");
Template["orNum"] = new Template("Template.orNum", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:orderNum", function() {
    return Spacebars.mustache(view.lookup("orderNum"));
  }));
}));

})();
