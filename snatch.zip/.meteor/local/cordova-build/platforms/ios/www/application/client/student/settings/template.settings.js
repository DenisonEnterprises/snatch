(function(){
Template.__checkName("settings");
Template["settings"] = new Template("Template.settings", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Settings"), "\n  "), "\n  ", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "student");
  }, function() {
    return [ "\n  \n  \n  ", HTML.DIV({
      "class": "settingsContainer"
    }, "\n   \n  ", HTML.H1("Settings"), "\n \n  ", HTML.H5({
      id: "notif"
    }, "Notif"), "\n \n \n  ", HTML.BUTTON({
      id: "changeUsername",
      "class": "normal"
    }, "Change Username"), "\n  \n  \n  ", HTML.BUTTON({
      id: "changePassword",
      "class": "normal"
    }, "Change Password"), "\n \n 	", HTML.BR(), "\n\n\n 	", HTML.FORM({
      id: "uNameForm"
    }, "\n		", HTML.LABEL("New Username"), "\n		", HTML.INPUT({
      type: "text",
      id: "newU"
    }), "\n		", HTML.BR(), "\n		", HTML.BUTTON({
      type: "submit"
    }, "Change"), "\n	"), "\n	\n 	", HTML.FORM({
      id: "pWordForm"
    }, "\n		", HTML.DIV({
      id: "old"
    }, "\n			", HTML.LABEL("Old Password"), "\n			", HTML.INPUT({
      type: "password",
      id: "oldP"
    }), "\n		"), "\n		", HTML.DIV({
      id: "new"
    }, "\n		", HTML.LABEL("New Password"), "\n			", HTML.INPUT({
      type: "password",
      id: "newP"
    }), "\n			", HTML.LABEL("Confirm New Password"), "\n			", HTML.INPUT({
      type: "password",
      id: "cnp"
    }), "\n		"), "\n		", HTML.BUTTON({
      type: "submit",
      id: "pwSubmit"
    }, "Change"), "\n	"), "\n	\n\n \n  ", HTML.BUTTON({
      id: "rmAccount",
      "class": "remove"
    }, "Delete Account"), "\n \n	", HTML.DIV({
      id: "delForm",
      "class": "delForm"
    }, "\n		", HTML.H4({
      id: "msg"
    }, "Are you certain you want to delete your account?"), "\n		", HTML.BUTTON({
      id: "yes",
      "class": "remove"
    }, "YES"), "\n		", HTML.BUTTON({
      id: "no"
    }, "NO"), "\n	"), "\n \n ", HTML.BR(), "\n ", HTML.BUTTON({
      id: "back"
    }, "Main Menu"), "\n \n  "), "\n  \n  \n    \n    " ];
  }, function() {
    return [ "\n    \n     ", Spacebars.include(view.lookupTemplate("denied")), "\n  \n    " ];
  }) ];
}));

})();
