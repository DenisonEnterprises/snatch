(function(){
Template.__checkName("orderList");
Template["orderList"] = new Template("Template.orderList", (function() {
  var view = this;
  return [ HTML.Raw("<!--   {{#if isInRole 'employee'}} -->\n  \n  "), HTML.STYLE("\ntable, th, td {\n    border: solid #005f5f 3px;\n}\n"), "\n\n  ", HTML.DIV({
    "class": "orderListContainer"
  }, " \n   	", HTML.Raw('<div class="nav">\n		<ul>\n			<li><button type="button" id="swapBTN">Incoming Orders</button></li>\n		</ul>\n	</div>'), "\n      ", HTML.Raw("<br>"), "\n      ", HTML.Raw("<br>"), "\n     ", HTML.Raw('<h1 align="center">All Items</h1>'), "\n     ", HTML.Raw("<br>"), "\n        ", Spacebars.include(view.lookupTemplate("itemInfo")), "\n  \n  ") ];
}));

Template.__checkName("itemInfo");
Template["itemInfo"] = new Template("Template.itemInfo", (function() {
  var view = this;
  return HTML.FORM({
    id: "order_list"
  }, "        \n        ", HTML.TABLE({
    align: "center"
  }, "\n        ", HTML.TR("\n          ", HTML.TH(" Pepperoni Bagels "), "\n          ", HTML.TH(Blaze.View("lookup:pepPizzaNum", function() {
    return Spacebars.mustache(view.lookup("pepPizzaNum"));
  })), "\n          "), "\n          ", HTML.TR("\n          ", HTML.TH(" Cheese Bagels "), "\n          ", HTML.TH(Blaze.View("lookup:CheesePizzaNum", function() {
    return Spacebars.mustache(view.lookup("CheesePizzaNum"));
  })), "\n          "), "\n          ", HTML.TR("\n          ", HTML.TH(" Snagel"), "\n          ", HTML.TH(Blaze.View("lookup:snagelNum", function() {
    return Spacebars.mustache(view.lookup("snagelNum"));
  })), "\n          "), "\n          ", HTML.TR("\n          ", HTML.TH(" Oreo Nutella Milkshakes "), "\n          ", HTML.TH(Blaze.View("lookup:onShakes", function() {
    return Spacebars.mustache(view.lookup("onShakes"));
  })), "\n       "), "\n     "), " \n  ");
}));

})();
