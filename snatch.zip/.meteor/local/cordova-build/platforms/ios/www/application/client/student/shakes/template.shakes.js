(function(){
Template.__checkName("shakes");
Template["shakes"] = new Template("Template.shakes", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Shakes"), "\n  "), "\n \n  \n  ", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "student");
  }, function() {
    return [ "\n  \n    ", HTML.DIV({
      "class": "shakesContainer"
    }, "\n   \n    ", HTML.DIV({
      "class": "nav"
    }, "\n       ", HTML.UL("\n          ", HTML.LI(Blaze.View("lookup:currentUser.username", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "username"));
    })), "\n          ", HTML.LI({
      "class": "Settings"
    }, "\n            ", HTML.A({
      href: "/settings"
    }, "\n              ", HTML.IMG({
      src: "img/sm/settingsSM.png",
      alt: "Settings"
    }), "\n            "), "\n          "), "\n          \n          ", HTML.LI({
      "class": "Info"
    }, "\n            ", HTML.A({
      href: "/about"
    }, "\n              ", HTML.IMG({
      src: "img/sm/infoSM.png",
      alt: "Info"
    }), "\n            "), "\n          "), "\n\n          ", HTML.LI({
      "class": "Logout"
    }, "\n              ", HTML.BUTTON({
      "class": "logout",
      id: "logout"
    }, "Logout"), "\n          "), "\n          \n          \n      "), "\n    "), " \n      \n      ", HTML.H1("Shakes"), "  \n    \n    ", HTML.H3("$2.75 per Shake"), "\n    \n    ", HTML.H4("Flavors"), "\n    \n", HTML.B(" Pick one please!"), "\n       ", HTML.FORM({
      name: "flavor",
      id: "flavor_list"
    }, "\n          ", HTML.UL("\n            ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("flavor"));
    }, function() {
      return [ "\n              ", Spacebars.include(view.lookupTemplate("flavorBox")), "\n            " ];
    }), "\n          "), "\n        "), "\n    \n    ", HTML.H4("Mix-ins"), "\n   \n      ", HTML.FORM({
      id: "mixin_list"
    }, "\n        \n", HTML.B("Pick Only Three Please!"), " \n        \n        ", HTML.BR(), "\n        ", HTML.UL("\n          ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("mixin"));
    }, function() {
      return [ "\n            ", Spacebars.include(view.lookupTemplate("mixinBox")), "\n          " ];
    }), "\n        "), "\n      ", HTML.BR(), "\n        ", HTML.BUTTON({
      type: "button",
      id: "backBTN",
      "class": "backButton"
    }, "Menu"), "\n\n        ", HTML.BUTTON({
      type: "submit",
      "class": "atcButton"
    }, "Add To Cart"), "\n      "), "  \n    ", HTML.DIV({
      "class": "teal"
    }, "\n    	", HTML.BUTTON({
      type: "button",
      id: "bagelBTN"
    }, "Bagels"), "\n    	", HTML.BUTTON({
      type: "button",
      id: "bevsBTN"
    }, "Beverages"), "\n    	", HTML.BUTTON({
      type: "button",
      id: "snackBTN"
    }, "Snacks"), "\n	"), "\n  "), " \n  \n    " ];
  }, function() {
    return [ "\n      ", Spacebars.include(view.lookupTemplate("denied")), "\n    " ];
  }) ];
}));

Template.__checkName("flavorBox");
Template["flavorBox"] = new Template("Template.flavorBox", (function() {
  var view = this;
  return HTML.LI("\n    ", HTML.INPUT({
    type: "checkbox",
    id: function() {
      return Spacebars.mustache(view.lookup("flavorName"));
    },
    name: function() {
      return Spacebars.mustache(view.lookup("flavorName"));
    },
    value: "2.75"
  }), "\n    ", HTML.SPAN({
    "class": "text"
  }, Blaze.View("lookup:flavorName", function() {
    return Spacebars.mustache(view.lookup("flavorName"));
  })), "\n  ");
}));

Template.__checkName("mixinBox");
Template["mixinBox"] = new Template("Template.mixinBox", (function() {
  var view = this;
  return HTML.LI("\n    ", HTML.INPUT({
    type: "checkbox",
    id: function() {
      return Spacebars.mustache(view.lookup("mixinName"));
    },
    name: function() {
      return Spacebars.mustache(view.lookup("mixinName"));
    },
    value: "2.75"
  }), "\n    ", HTML.SPAN({
    "class": "text"
  }, Blaze.View("lookup:mixinName", function() {
    return Spacebars.mustache(view.lookup("mixinName"));
  })), "\n  ");
}));

})();
