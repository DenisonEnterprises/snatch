(function(){
Template.__checkName("denied");
Template["denied"] = new Template("Template.denied", (function() {
  var view = this;
  return [ HTML.Raw('<div class="denied">\n    <img src="img/accessdenied.png" alt="Acess Denied!">\n    <br>\n    <button class="deniedLogin" onclick="deniedLogin()">Log In</button>\n  </div>\n  \n  '), HTML.SCRIPT("\n\n    \n    //setTimeout(function(){  }, 3000);\n\n    \n    \n    function deniedLogin() {\n      window.location.href = '/';\n    }\n    \n  ") ];
}));

Template.__checkName("deniedEmp");
Template["deniedEmp"] = new Template("Template.deniedEmp", (function() {
  var view = this;
  return [ HTML.Raw('<div class="denied">\n    <img src="img/acessdeniedemployee.png" alt="Acess Denied!">\n    <br>\n    <button class="deniedLogin" onclick="deniedLogin()">Log In</button>\n  </div>\n  \n  '), HTML.SCRIPT("\n\n    \n    //setTimeout(function(){  }, 3000);\n\n    \n    \n    function deniedLogin() {\n      window.location.href = '/';\n    }\n    \n  ") ];
}));

})();
