(function(){
Template.__checkName("forgot");
Template["forgot"] = new Template("Template.forgot", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Forgot"), "\n  "), HTML.Raw('\n  \n  \n  <div class="forgotContainer">\n   \n  <h1>Forgot Password</h1>\n \n  <h5 id="notif" class="notif">Notif</h5>\n \n \n\n 	<form id="forgotForm">\n		<label>Email</label>\n		<input type="text" id="email">\n		<br>\n		<button type="submit">Submit</button>\n	</form>\n	\n 	\n	\n \n <br>\n <button id="back">Back</button>\n \n  </div>') ];
}));

})();
