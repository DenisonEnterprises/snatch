(function(){
Template.__checkName("menu");
Template["menu"] = new Template("Template.menu", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Menu"), "\n  "), "\n  \n   ", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "student");
  }, function() {
    return [ "\n  \n  ", HTML.DIV({
      "class": "menuContainer"
    }, "\n       \n    ", HTML.DIV({
      "class": "nav"
    }, "\n       ", HTML.UL("\n          ", HTML.LI(Blaze.View("lookup:currentUser.username", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "username"));
    })), "\n          ", HTML.LI({
      "class": "Settings"
    }, "\n            ", HTML.A({
      href: "/settings"
    }, "\n              ", HTML.IMG({
      src: "img/sm/settingsSM.png",
      alt: "Settings"
    }), "\n            "), "\n          "), "\n          \n          ", HTML.LI({
      "class": "Info"
    }, "\n            ", HTML.A({
      href: "/about"
    }, "\n              ", HTML.IMG({
      src: "img/sm/infoSM.png",
      alt: "Info"
    }), "\n            "), "\n          "), "\n         \n         ", HTML.LI({
      "class": "Logout"
    }, " \n              ", HTML.BUTTON({
      "class": "logout",
      id: "logout"
    }, "Logout"), "\n         "), "\n          \n      "), "\n    "), " \n   \n\n \n    ", HTML.DIV({
      "class": "middle"
    }, "\n      ", HTML.H1("Main Menu"), "\n       ", HTML.BR(), "\n       ", HTML.BUTTON({
      "class": "bagelBTN",
      id: "bagelBTN"
    }, "Bagels"), "\n      \n       ", HTML.BUTTON({
      "class": "shakesBTN",
      id: "shakesBTN"
    }, "Milkshakes"), "\n      \n       ", HTML.BUTTON({
      "class": "bevsBTN",
      id: "bevsBTN"
    }, "Beverages"), "\n      \n       ", HTML.BUTTON({
      "class": "snackBTN",
      id: "snackBTN"
    }, " Snacks "), "\n      \n       ", HTML.BR(), "\n      \n      ", HTML.DIV({
      "class": "cart"
    }, "\n       ", HTML.BUTTON({
      id: "cout",
      "class": "cout"
    }, "Checkout\n       ", HTML.IMG({
      src: "img/lg/Grocery-CartLG.png",
      alt: "Cart"
    })), "\n      "), "\n      \n      ", HTML.DIV({
      "class": "notif"
    }, "\n      ", HTML.IMG({
      src: "img/cartupdate-3.png",
      alt: "Order Updated!",
      id: "notif"
    }), "\n      "), "\n    "), "\n  \n  "), " \n  \n  " ];
  }, function() {
    return [ "\n    \n     ", Spacebars.include(view.lookupTemplate("denied")), "\n  \n  " ];
  }) ];
}));

})();
