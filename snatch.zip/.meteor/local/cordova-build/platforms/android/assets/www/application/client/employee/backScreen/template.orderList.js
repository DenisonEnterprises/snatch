(function(){
Template.__checkName("orderList");
Template["orderList"] = new Template("Template.orderList", (function() {
  var view = this;
  return Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "employee");
  }, function() {
    return [ "\n  \n  ", HTML.STYLE("\ntable, th, td {\n    border: solid #005f5f 3px;\n}\n"), "\n\n  ", HTML.DIV({
      "class": "orderListContainer"
    }, " \n   	", HTML.DIV({
      "class": "nav"
    }, "\n		", HTML.UL("\n			", HTML.LI(HTML.BUTTON({
      type: "button",
      id: "swapBTN"
    }, "Incoming Orders")), "\n		"), "\n	"), "\n      ", HTML.BR(), "\n      ", HTML.BR(), "\n     ", HTML.H1({
      align: "center"
    }, "All Items"), "\n     ", HTML.BR(), "\n        ", Spacebars.include(view.lookupTemplate("itemInfo")), "\n  \n  "), "\n\n\n      " ];
  }, function() {
    return [ "\n       ", Spacebars.include(view.lookupTemplate("deniedEmp")), "\n    " ];
  });
}));

Template.__checkName("itemInfo");
Template["itemInfo"] = new Template("Template.itemInfo", (function() {
  var view = this;
  return HTML.FORM({
    id: "order_list"
  }, "        \n        ", HTML.TABLE({
    align: "center"
  }, "\n        ", HTML.TR("\n          ", HTML.TH(" Pepperoni Bagels "), "\n          ", HTML.TH(Blaze.View("lookup:pepPizzaNum", function() {
    return Spacebars.mustache(view.lookup("pepPizzaNum"));
  })), "\n          "), "\n          ", HTML.TR("\n          ", HTML.TH(" Cheese Bagels "), "\n          ", HTML.TH(Blaze.View("lookup:CheesePizzaNum", function() {
    return Spacebars.mustache(view.lookup("CheesePizzaNum"));
  })), "\n          "), "\n          ", HTML.TR("\n          ", HTML.TH(" Snagel"), "\n          ", HTML.TH(Blaze.View("lookup:snagelNum", function() {
    return Spacebars.mustache(view.lookup("snagelNum"));
  })), "\n          "), "\n          ", HTML.TR("\n          ", HTML.TH(" Oreo Nutella Milkshakes "), "\n          ", HTML.TH(Blaze.View("lookup:onShakes", function() {
    return Spacebars.mustache(view.lookup("onShakes"));
  })), "\n       "), "\n     "), " \n  ");
}));

})();
