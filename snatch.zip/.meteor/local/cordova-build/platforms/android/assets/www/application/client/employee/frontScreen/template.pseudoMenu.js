(function(){
Template.__checkName("pseudoMenu");
Template["pseudoMenu"] = new Template("Template.pseudoMenu", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Menu"), "\n  "), "\n  \n\n\n  ", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "employee");
  }, function() {
    return [ "\n   \n   ", HTML.DIV({
      "class": "pseudoMenuContainer"
    }, "\n	   \n   		", HTML.TABLE({
      align: "center",
      cellpadding: "0",
      cellspacing: "0",
      border: "0"
    }, "\n			", HTML.TR({
      "class": "titles"
    }, "				\n				", HTML.TH(" Bagels "), "		\n				", HTML.TH({
      style: "width:350px"
    }, " Shakes "), "\n				", HTML.TH(" Beverages "), "\n				", HTML.TH(" Snacks "), "\n			"), "\n			", HTML.TR("\n				", HTML.TH(HTML.UL("				", HTML.Comment(" pseudoBagels "), "\n				", HTML.FORM({
      id: "bagelList"
    }, "\n				  ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("bagel"));
    }, function() {
      return [ "\n					", Spacebars.include(view.lookupTemplate("bagelBox")), "\n					", HTML.BR(), "\n				  " ];
    }), "\n				  "), "\n       			 ")), "\n       			 ", HTML.TH(HTML.UL("				", HTML.Comment(" pseudoShakes "), "\n       			 	", HTML.TR({
      style: "text-align:center"
    }, "\n       			 	", HTML.TH({
      "class": "flavMix"
    }, " Flavors "), "\n       			  ", HTML.TH({
      "class": "flavMix"
    }, " Mixins ")), "\n       			 	", HTML.TR(HTML.TH({
      "class": "inner1"
    }, HTML.UL("\n						", HTML.FORM({
      id: "flavList"
    }, "\n							", HTML.BR(), "\n							", Blaze.Each(function() {
      return Spacebars.call(view.lookup("flavor"));
    }, function() {
      return [ "\n							  ", Spacebars.include(view.lookupTemplate("flavorBox")), "\n							\n							" ];
    }), "     \n						"), "  			 	\n       			 	")), "\n       			 	", HTML.TH({
      "class": "inner2"
    }, HTML.UL("\n						", HTML.FORM({
      id: "mixList"
    }, "\n						  ", HTML.BR(), "\n						  ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("mixin"));
    }, function() {
      return [ "\n							", Spacebars.include(view.lookupTemplate("mixinBox")), "\n						  " ];
    }), "\n						  "), "\n       			 	"))), "\n       			 	\n       			 ")), "\n				", HTML.TH(HTML.UL("				", HTML.Comment(" pseudoBev "), "\n				", HTML.FORM({
      id: "bevList"
    }, "\n				  ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("bev"));
    }, function() {
      return [ "\n					", Spacebars.include(view.lookupTemplate("bevBox")), "\n					", HTML.BR(), "\n				  " ];
    }), "\n				  "), "\n				 ")), "\n				", HTML.TH(HTML.UL("				", HTML.Comment(" pseudoSnacks "), "\n				", HTML.FORM({
      id: "snackList"
    }, "\n		          ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("snack"));
    }, function() {
      return [ "\n					", Spacebars.include(view.lookupTemplate("snackBox")), "\n					", HTML.BR(), "\n				  " ];
    }), "\n				  "), "\n				")), "				 \n			"), "\n		"), "\n		\n  	   ", HTML.BUTTON({
      "class": "submit",
      id: "atcBTN"
    }, "Add To Cart"), "\n        ", HTML.DIV({
      "class": "nav"
    }, "\n  		", HTML.UL("\n  			", HTML.LI(HTML.BUTTON({
      type: "button",
      id: "swapBTN"
    }, "Pick Up Orders")), "\n  		"), "\n  	  "), "\n		\n        \n		\n   "), " \n     " ];
  }, function() {
    return [ "\n      ", Spacebars.include(view.lookupTemplate("deniedEmp")), "\n   " ];
  }) ];
}));

Template.__checkName("pbagelBox");
Template["pbagelBox"] = new Template("Template.pbagelBox", (function() {
  var view = this;
  return HTML.LI("\n    ", HTML.INPUT({
    type: "checkbox",
    id: function() {
      return Spacebars.mustache(view.lookup("bagelName"));
    },
    name: function() {
      return Spacebars.mustache(view.lookup("bagelName"));
    },
    value: function() {
      return Spacebars.mustache(view.lookup("bagelPrice"));
    }
  }), "\n    ", HTML.SPAN({
    "class": "text"
  }, Blaze.View("lookup:bagelName", function() {
    return Spacebars.mustache(view.lookup("bagelName"));
  })), "\n    ", HTML.SPAN({
    "class": "price"
  }, Blaze.View("lookup:bagelPrice", function() {
    return Spacebars.mustache(view.lookup("bagelPrice"));
  })), "\n  ");
}));

Template.__checkName("pbevBox");
Template["pbevBox"] = new Template("Template.pbevBox", (function() {
  var view = this;
  return HTML.LI("\n    ", HTML.INPUT({
    type: "checkbox",
    id: function() {
      return Spacebars.mustache(view.lookup("bevName"));
    },
    name: function() {
      return Spacebars.mustache(view.lookup("bevName"));
    },
    value: function() {
      return Spacebars.mustache(view.lookup("bevPrice"));
    }
  }), "\n    ", HTML.SPAN({
    "class": "text"
  }, Blaze.View("lookup:bevName", function() {
    return Spacebars.mustache(view.lookup("bevName"));
  })), "\n    ", HTML.SPAN({
    "class": "price"
  }, " ", Blaze.View("lookup:bevPrice", function() {
    return Spacebars.mustache(view.lookup("bevPrice"));
  }), " "), "\n  ");
}));

Template.__checkName("psnackBox");
Template["psnackBox"] = new Template("Template.psnackBox", (function() {
  var view = this;
  return HTML.LI("\n    ", HTML.INPUT({
    type: "checkbox",
    id: function() {
      return Spacebars.mustache(view.lookup("snackName"));
    },
    name: function() {
      return Spacebars.mustache(view.lookup("snackName"));
    },
    value: function() {
      return Spacebars.mustache(view.lookup("snackPrice"));
    }
  }), "\n    ", HTML.SPAN({
    "class": "text"
  }, Blaze.View("lookup:snackName", function() {
    return Spacebars.mustache(view.lookup("snackName"));
  })), "\n    ", HTML.SPAN({
    "class": "price"
  }, " ", Blaze.View("lookup:snackPrice", function() {
    return Spacebars.mustache(view.lookup("snackPrice"));
  }), " "), "\n  ");
}));

Template.__checkName("pflavorBox");
Template["pflavorBox"] = new Template("Template.pflavorBox", (function() {
  var view = this;
  return HTML.LI("\n    ", HTML.INPUT({
    type: "checkbox",
    id: function() {
      return Spacebars.mustache(view.lookup("flavorName"));
    },
    name: function() {
      return Spacebars.mustache(view.lookup("flavorName"));
    },
    value: "2.75"
  }), "\n    ", HTML.SPAN({
    "class": "text"
  }, Blaze.View("lookup:flavorName", function() {
    return Spacebars.mustache(view.lookup("flavorName"));
  })), "\n  ");
}));

Template.__checkName("pmixinBox");
Template["pmixinBox"] = new Template("Template.pmixinBox", (function() {
  var view = this;
  return HTML.LI("\n    ", HTML.INPUT({
    type: "checkbox",
    id: function() {
      return Spacebars.mustache(view.lookup("mixinName"));
    },
    name: function() {
      return Spacebars.mustache(view.lookup("mixinName"));
    },
    value: "2.75"
  }), "\n    ", HTML.SPAN({
    "class": "text"
  }, Blaze.View("lookup:mixinName", function() {
    return Spacebars.mustache(view.lookup("mixinName"));
  })), "\n  ");
}));

})();
