(function(){
Template.__checkName("pseudoCheck");
Template["pseudoCheck"] = new Template("Template.pseudoCheck", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Checkout"), "\n  "), "\n    \n  \n  ", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "employee");
  }, function() {
    return [ "\n\n\n   ", HTML.DIV({
      "class": "pseudoCheckContainer"
    }, "\n    \n     \n     ", HTML.DIV({
      "class": "cout"
    }, "\n    \n \n  \n       ", HTML.IMG({
      src: "img/checkTop.png",
      alt: "CheckTop"
    }), "\n  ", HTML.BR(), "\n\n      ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("order"));
    }, function() {
      return [ "\n       \n       ", HTML.DIV({
        "class": "line"
      }, "\n         \n         ", HTML.DIV({
        "class": "rmBtn"
      }, "\n           ", HTML.DIV({
        "class": "moveBtn"
      }, "\n             ", HTML.BUTTON({
        name: function() {
          return Spacebars.mustache(view.lookup("item"));
        },
        id: "deleteOrder",
        "class": "button-check"
      }, "X"), "\n           "), "\n         "), "\n         \n         \n         ", HTML.DIV({
        "class": "itemz"
      }, "\n           ", HTML.DIV({
        "class": "moveItem"
      }, "\n           ", Blaze.View("lookup:item", function() {
        return Spacebars.mustache(view.lookup("item"));
      }), "\n           "), "\n         "), "\n         \n         \n         \n         \n         \n         \n         ", HTML.DIV({
        "class": "price"
      }, "\n           ", HTML.DIV({
        "class": "movePrice"
      }, "\n          ", Blaze.View("lookup:price", function() {
        return Spacebars.mustache(view.lookup("price"));
      }), "\n           "), "\n         "), "\n         \n         \n         \n         ", HTML.BR(), "\n       "), "\n       \n       ", HTML.DIV({
        "class": "line"
      }, "\n         ", HTML.BR(), "\n       "), "\n       \n      \n       \n    " ];
    }), "\n       \n 	  ", HTML.DIV({
      "class": "totalPrice"
    }, "\n		  	", HTML.IMG({
      src: "img/checkBottom.png",
      alt: "CheckBottom"
    }), "\n		  ", HTML.DIV({
      "class": "price"
    }, "\n 				    ", Spacebars.include(view.lookupTemplate("totalPrice")), "\n				"), "\n       	\n	    "), "\n ", HTML.BR(), "\n  ", HTML.DIV({
      "class": "miniText"
    }, "\n  	", HTML.BUTTON(" There are ", Spacebars.include(view.lookupTemplate("orNum")), " Orders in front of yours. "), "\n "), "\n ", HTML.BR(), "\n ", HTML.BR(), "\n ", HTML.BR(), "\n    ", HTML.BUTTON({
      "class": "backBTN",
      id: "menu"
    }, "Menu"), "  \n    ", HTML.BUTTON({
      "class": "placeOrderBTN",
      id: "placeOrder"
    }, "Place Order"), "\n    \n       \n       \n\n       \n     "), "\n  "), "\n  \n    " ];
  }, function() {
    return [ "\n     ", Spacebars.include(view.lookupTemplate("deniedEmp")), "\n    " ];
  }) ];
}));

})();
