(function(){Template.about.events({
  "click #backBTN": function( evt, instance ){
    Router.go('menu');
  },

});

})();
