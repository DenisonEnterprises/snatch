(function(){
Template.__checkName("deniedEmp");
Template["deniedEmp"] = new Template("Template.deniedEmp", (function() {
  var view = this;
  return HTML.Raw('<div class="deniedEmp">\n    <img src="img/deniedEmp.png" alt="Acess Denied!">\n    <br>\n    <button class="deniedLogin" id="deniedLogin">Log In</button>\n  </div>');
}));

})();
