(function(){
Template.__checkName("menuLoading");
Template["menuLoading"] = new Template("Template.menuLoading", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Menu"), "\n  "), "\n  \n  ", HTML.DIV({
    "class": "menuContainer"
  }, "\n       \n    ", HTML.DIV({
    "class": "nav"
  }, "\n       ", HTML.UL("\n          ", HTML.LI(Blaze.View("lookup:currentUser.username", function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "username"));
  })), "\n          ", HTML.Raw('<li class="Settings">\n              <img src="img/sm/settingsSM.png" alt="Settings">\n          </li>'), "\n       \n          ", HTML.Raw('<li class="Info">\n              <img src="img/sm/infoSM.png" alt="Info"> \n          </li>'), "\n         \n         ", HTML.Raw('<li class="Logout">\n              <button class="logout">Logout</button>\n         </li>'), "\n          \n      "), "\n    "), " \n   \n\n \n    ", HTML.Raw('<div class="middle">\n      <h1>Main Menu</h1>\n       <br>\n       <button class="bagelBTN">Bagels</button>\n      \n       <button class="shakesBTN">Milkshakes</button>\n      \n       <button class="bevsBTN">Beverages</button>\n      \n       <button class="snackBTN"> Snacks </button>\n      \n       <br>\n      \n      <div class="cart">\n       <button class="cout">Checkout\n       <img src="img/lg/Grocery-CartLG.png" alt="Cart"></button>\n      </div>\n      \n      <div class="notif">\n      <img src="img/cartupdate-3.png" alt="Order Updated!" id="notif">\n      </div>\n    </div>'), "\n  \n  \n  \n  		\n  \n  \n  ") ];
}));

})();
