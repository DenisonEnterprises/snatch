(function(){
Template.__checkName("denied");
Template["denied"] = new Template("Template.denied", (function() {
  var view = this;
  return HTML.Raw('<div class="denied">\n    <img src="img/accessdenied.png" alt="Acess Denied!">\n    <br>\n    <button class="deniedLogin" id="deniedLogin">Log In</button>\n  </div>');
}));

})();
