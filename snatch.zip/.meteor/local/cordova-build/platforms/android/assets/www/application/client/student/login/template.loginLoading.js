(function(){
Template.__checkName("loginLoading");
Template["loginLoading"] = new Template("Template.loginLoading", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Login"), "\n  "), HTML.Raw('\n  \n  <div class="loginContainer">\n\n    \n    <div class="cntr">\n      \n      <img src="img/lg/logoLG.png" alt="Bandersnatch Logo">\n      \n      <br>\n      <br>\n      <form id="login-form">\n          <label for="login-username"></label><input type="text" id="login-username" placeholder="Username">\n          <label for="login-password"></label><input type="password" id="login-password" placeholder="Password">\n		  <br>\n		  <br>\n	            <button type="submit" class="normal">Log In</button>\n	        </form>\n  \n	    	<button id="signUp" class="normal">Sign Up</button>\n      \n	  	  <br>\n        \n	  		<button id="forgot" class="forgot">Forgot Password?</button>\n      \n        \n    </div>\n    \n    <div class="ftr">\n      \n      <a href="http://www.denisonenterprises.squarespace.com"> <img src="/img/DELogo.png" alt="DElogo"> </a>\n      <p><a href="http://www.denisonenterprises.squarespace.com" target="_blank">D E N I S O N E N T E R P R I S E S</a></p>\n    </div>\n  \n   \n    </div>') ];
}));

})();
