(function(){Template.deniedEmp.events({
	
	'click #deniedLogin' : function() {
		Router.go('/');
	},
	
});

})();
