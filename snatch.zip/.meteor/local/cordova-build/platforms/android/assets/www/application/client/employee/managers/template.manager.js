(function(){
Template.__checkName("manager");
Template["manager"] = new Template("Template.manager", (function() {
  var view = this;
  return [ HTML.HEAD("\n	", HTML.TITLE(" Bandersnatch - Managers "), "\n"), "	\n	\n	", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "manager");
  }, function() {
    return [ "\n	", HTML.H1(" Managers "), "\n	\n	\n	\n  \n    " ];
  }, function() {
    return [ "\n     ", Spacebars.include(view.lookupTemplate("deniedEmp")), "\n    " ];
  }) ];
}));

})();
