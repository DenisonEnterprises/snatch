(function(){
Template.__checkName("employee");
Template["employee"] = new Template("Template.employee", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Employee"), "\n  "), "\n  \n   ", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "employee");
  }, function() {
    return [ "\n  \n  ", HTML.STYLE("\ntable, th, td {\n    border: solid #005f5f 3px;\n}\n"), "\n\n  ", HTML.DIV({
      "class": "employeeContainer"
    }, " \n   	", HTML.DIV({
      "class": "nav"
    }, "\n		", HTML.UL("\n			", HTML.BUTTON({
      type: "button",
      id: "swapBTN"
    }, "List of Ordered Items"), "\n		"), "\n	"), "\n      ", HTML.BR(), "\n      ", HTML.BR(), "\n       \n      ", HTML.H1({
      align: "center"
    }, "Current Orders"), "\n     ", HTML.BR(), "\n      ", HTML.BR(), "\n        ", Spacebars.include(view.lookupTemplate("orderInfo")), "\n  \n  "), "\n    \n    " ];
  }, function() {
    return [ "\n     ", Spacebars.include(view.lookupTemplate("deniedEmp")), "\n  " ];
  }) ];
}));

Template.__checkName("orderInfo");
Template["orderInfo"] = new Template("Template.orderInfo", (function() {
  var view = this;
  return HTML.FORM({
    id: "order_list"
  }, "\n     \n      \n      ", HTML.TABLE({
    align: "center"
  }, "\n        ", HTML.TR({
    "class": "titles"
  }, "\n          ", HTML.TH({
    style: "width: 100px"
  }, " DELETE "), "\n          ", HTML.TH({
    style: "width: 130px"
  }, " Username "), "\n          ", HTML.TH({
    style: "width:150px"
  }, " Cell Phone Number "), "\n          ", HTML.TH({
    style: "width: 100px"
  }, " Time of Order "), "\n          ", HTML.TH({
    style: "width: 100px"
  }, " Order Number "), "\n		  ", HTML.TH({
    style: "width:100px"
  }, " In House? "), "\n          ", HTML.TH({
    style: "width: 200px"
  }, " Order "), "\n          ", HTML.TH({
    style: "width: 100px"
  }, " Finished? "), "\n       "), "\n        ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("order"));
  }, function() {
    return [ "\n       ", HTML.TR("\n       		", HTML.TD({
      "class": "delete",
      style: "width: 100px"
    }, Spacebars.include(view.lookupTemplate("deleteBTN"))), "\n          ", HTML.TD({
      style: "width: 130px"
    }, Spacebars.include(view.lookupTemplate("order1"))), "\n         ", HTML.TD({
      style: "width: 150px"
    }, Spacebars.include(view.lookupTemplate("cellNum"))), "\n          ", HTML.TD({
      style: "width: 100px"
    }, Spacebars.include(view.lookupTemplate("order3"))), "\n         ", HTML.TD({
      style: "width: 100px"
    }, Spacebars.include(view.lookupTemplate("orderNum"))), "\n		 ", HTML.TD({
      style: "width:100px"
    }, Spacebars.include(view.lookupTemplate("inHaus"))), "\n         ", HTML.TD({
      style: "width: 200px"
    }, Spacebars.include(view.lookupTemplate("order2"))), "\n          ", HTML.TD({
      "class": "done",
      style: "width: 100px"
    }, Spacebars.include(view.lookupTemplate("done"))), "\n       "), "   \n        " ];
  }), "\n     "), " \n  ");
}));

Template.__checkName("deleteBTN");
Template["deleteBTN"] = new Template("Template.deleteBTN", (function() {
  var view = this;
  return HTML.Raw('<button id="deleBTN"> Delete </button>');
}));

Template.__checkName("cellNum");
Template["cellNum"] = new Template("Template.cellNum", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:cellNum", function() {
    return Spacebars.mustache(view.lookup("cellNum"));
  }));
}));

Template.__checkName("inHaus");
Template["inHaus"] = new Template("Template.inHaus", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:inHaus", function() {
    return Spacebars.mustache(view.lookup("inHaus"));
  }));
}));

Template.__checkName("order1");
Template["order1"] = new Template("Template.order1", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:userName", function() {
    return Spacebars.mustache(view.lookup("userName"));
  }));
}));

Template.__checkName("order2");
Template["order2"] = new Template("Template.order2", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:orderDeets", function() {
    return Spacebars.mustache(view.lookup("orderDeets"));
  }));
}));

Template.__checkName("order3");
Template["order3"] = new Template("Template.order3", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:orderTime", function() {
    return Spacebars.mustache(view.lookup("orderTime"));
  }));
}));

Template.__checkName("orderNum");
Template["orderNum"] = new Template("Template.orderNum", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:orderNum", function() {
    return Spacebars.mustache(view.lookup("orderNum"));
  }));
}));

Template.__checkName("done");
Template["done"] = new Template("Template.done", (function() {
  var view = this;
  return HTML.Raw('<button id="finished">Finished</button>');
}));

})();
