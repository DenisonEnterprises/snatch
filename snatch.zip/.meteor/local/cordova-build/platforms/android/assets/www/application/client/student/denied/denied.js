(function(){Template.denied.events({
	
	'click #deniedLogin' : function() {
		Router.go('/');
	},
	
});

})();
