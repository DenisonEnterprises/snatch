(function(){Template.thanksForm.events({
    "click #thankYou": function( evt, instance ){
      Router.go('/');
    },
});

})();
