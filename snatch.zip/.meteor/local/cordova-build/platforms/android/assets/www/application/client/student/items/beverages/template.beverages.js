(function(){
Template.__checkName("beverages");
Template["beverages"] = new Template("Template.beverages", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Beverages"), "\n  "), "\n  \n  ", Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "student");
  }, function() {
    return [ "\n\n\n  \n  \n  ", HTML.DIV({
      "class": "itemContainer"
    }, "\n    \n    ", HTML.DIV({
      "class": "nav"
    }, "\n       ", HTML.UL("\n          ", HTML.LI(Blaze.View("lookup:currentUser.username", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "username"));
    })), "\n          ", HTML.LI({
      "class": "Settings"
    }, "\n            ", HTML.A({
      href: "/settings"
    }, "\n              ", HTML.IMG({
      src: "img/sm/settingsSM.png",
      alt: "Settings"
    }), "\n            "), "\n          "), "\n          \n          ", HTML.LI({
      "class": "Info"
    }, "\n            ", HTML.A({
      href: "/about"
    }, "\n              ", HTML.IMG({
      src: "img/sm/infoSM.png",
      alt: "Info"
    }), "\n            "), "\n          "), "\n         ", HTML.LI({
      "class": "Logout"
    }, "\n              ", HTML.BUTTON({
      "class": "logout",
      type: "button",
      id: "logout"
    }, "Logout"), "\n          "), "\n      \n          \n      "), "\n    "), " \n    \n      ", HTML.H1("Beverages"), "\n\n      ", HTML.FORM({
      id: "bev_list"
    }, "\n        ", HTML.UL("\n          ", Blaze.Each(function() {
      return Spacebars.call(view.lookup("bev"));
    }, function() {
      return [ "\n            ", Spacebars.include(view.lookupTemplate("bevBox")), "\n          " ];
    }), "\n        "), "\n        ", HTML.BUTTON({
      type: "button",
      "class": "backButton",
      id: "backBTN"
    }, "Menu"), "\n        ", HTML.BUTTON({
      type: "submit",
      "class": "atcButton",
      id: "atcButton",
      disabled: "disabled"
    }, "Add To Cart"), "\n      "), "\n        \n	", HTML.DIV({
      "class": "teal"
    }, "\n    	", HTML.BUTTON({
      type: "button",
      id: "shakesBTN"
    }, "Shakes"), "\n    	", HTML.BUTTON({
      type: "button",
      id: "bagelBTN"
    }, "Bagels"), "\n   	 	", HTML.BUTTON({
      type: "button",
      id: "snackBTN"
    }, "Snacks"), "\n	"), "\n      \n  "), "\n    \n  \n    " ];
  }, function() {
    return [ "\n    \n     ", Spacebars.include(view.lookupTemplate("denied")), "\n  \n    " ];
  }) ];
}));

Template.__checkName("bevBox");
Template["bevBox"] = new Template("Template.bevBox", (function() {
  var view = this;
  return HTML.LI("\n    ", HTML.INPUT({
    type: "checkbox",
    id: function() {
      return Spacebars.mustache(view.lookup("bevName"));
    },
    name: function() {
      return Spacebars.mustache(view.lookup("bevName"));
    },
    value: function() {
      return Spacebars.mustache(view.lookup("bevPrice"));
    }
  }), "\n    ", HTML.SPAN({
    "class": "text"
  }, Blaze.View("lookup:bevName", function() {
    return Spacebars.mustache(view.lookup("bevName"));
  })), "\n    ", HTML.SPAN({
    "class": "price"
  }, " ", Blaze.View("lookup:bevPrice", function() {
    return Spacebars.mustache(view.lookup("bevPrice"));
  }), " "), "\n  ");
}));

})();
