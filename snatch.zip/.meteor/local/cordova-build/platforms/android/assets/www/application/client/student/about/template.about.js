(function(){
Template.__checkName("about");
Template["about"] = new Template("Template.about", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - About"), "\n  "), HTML.Raw('\n\n  \n  \n  <div class="aboutcontainer">\n  \n   \n   <div class="wrapper">\n   <h1>About Us</h1>\n\n    <br>\n    <br>\n   \n    \n    <p>Denison Enterprises was founded in 2014 when students recognized there were no outlets for hands-on business experience on campus. Currently, the group is working with the Bandersnatch, helping to transition the late-night snack spot to run like a true business.\n    <br>\n    <br>\n    This application was created by the Denison Enterprises Sofware Development Team with the goals of digitizing the ordering process, implementing a record keeping system, allowing management to make statistically informed business decisions, reducing wait times, and ultimately bettering the Bandersnatch experience!</p>\n    </div>\n    <button class="backButton" id="backBTN">Main Menu</button>\n  </div>') ];
}));

})();
