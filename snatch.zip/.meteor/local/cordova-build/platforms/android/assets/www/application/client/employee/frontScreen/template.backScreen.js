(function(){
Template.__checkName("backScreen");
Template["backScreen"] = new Template("Template.backScreen", (function() {
  var view = this;
  return Blaze.If(function() {
    return Spacebars.dataMustache(view.lookup("isInRole"), "employee");
  }, function() {
    return [ "\n  \n  ", HTML.STYLE("\ntable, th, td {\n    border: solid #005f5f 5px;\n}\n"), "\n\n\n    ", HTML.DIV({
      "class": "backScreenBackgound"
    }, "\n	"), "\n	\n	\n  ", HTML.DIV({
      "class": "backScreenContainer"
    }, " \n   	", HTML.DIV({
      "class": "nav"
    }, "\n		", HTML.UL("\n			", HTML.LI(HTML.BUTTON({
      type: "button",
      id: "swapBTN"
    }, "Main Menu")), "\n		"), "\n	"), "\n\n      ", HTML.H1({
      align: "center"
    }, "Ready for Pick Up"), "\n      ", HTML.BR(), "\n      ", HTML.BR(), "\n        ", Spacebars.include(view.lookupTemplate("readyInfo")), "\n\n 	  \n  "), "\n    \n    \n    " ];
  }, function() {
    return [ "\n     ", Spacebars.include(view.lookupTemplate("deniedEmp")), "\n  " ];
  });
}));

Template.__checkName("readyInfo");
Template["readyInfo"] = new Template("Template.readyInfo", (function() {
  var view = this;
  return HTML.FORM({
    id: "ready_list"
  }, "        \n        ", HTML.TABLE({
    align: "center"
  }, "\n        ", HTML.TR({
    "class": "titles"
  }, "\n          ", HTML.TH(" Username "), "\n          ", HTML.TH(" Cell Phone Number "), "\n          ", HTML.TH(" Order Number "), "\n          ", HTML.TH(" Items "), "\n          ", HTML.TH(" Total Price "), " \n          ", HTML.TH(" Picked Up? "), "\n       "), "\n        ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("ready"));
  }, function() {
    return [ "\n       ", HTML.TR("\n          ", HTML.TD({
      align: "center"
    }, Spacebars.include(view.lookupTemplate("ready1"))), "\n         ", HTML.TD({
      align: "center"
    }, Spacebars.include(view.lookupTemplate("cellNum"))), "\n         ", HTML.TD({
      align: "center"
    }, Spacebars.include(view.lookupTemplate("orderNum"))), "\n         ", HTML.TD({
      align: "left"
    }, Spacebars.include(view.lookupTemplate("order2"))), "\n         ", HTML.TD({
      align: "center"
    }, Spacebars.include(view.lookupTemplate("orderPrice"))), "  \n          ", HTML.TD({
      align: "center"
    }, HTML.BUTTON({
      id: "pickUp"
    }, "Picked Up")), "\n       "), "   \n        " ];
  }), "\n     "), " \n  ");
}));

Template.__checkName("ready1");
Template["ready1"] = new Template("Template.ready1", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:readyName", function() {
    return Spacebars.mustache(view.lookup("readyName"));
  }));
}));

Template.__checkName("orderPrice");
Template["orderPrice"] = new Template("Template.orderPrice", (function() {
  var view = this;
  return HTML.SPAN(Blaze.View("lookup:price", function() {
    return Spacebars.mustache(view.lookup("price"));
  }));
}));

})();
