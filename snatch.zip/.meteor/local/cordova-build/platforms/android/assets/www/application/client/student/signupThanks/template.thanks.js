(function(){
Template.__checkName("thanksForm");
Template["thanksForm"] = new Template("Template.thanksForm", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Bandersnatch - Thanks!"), "\n  "), HTML.Raw(' \n  \n  <div class="thanksContainer">\n  \n    <div class="thanksText">\n      <p>Thank you for signing up for the Bandersnatch App.</p>\n      <p>Please check your Denison email for a verification link!</p>\n      <p>If it does not show up within a few minutes, please check your junk mail.</p>\n    </div>\n  <button id="thankYou">Thank You</button>\n    \n    <div class="ftr">\n      <img src="/img/ThankYou1.png" alt="ThankYou">\n    </div>\n    \n      \n    \n  </div>') ];
}));

})();
