(function(){
Template.__checkName("thankYouCheckout");
Template["thankYouCheckout"] = new Template("Template.thankYouCheckout", (function() {
  var view = this;
  return [ HTML.HEAD("\n    ", HTML.TITLE("Thank you for your order!"), "\n  "), HTML.Raw('\n  \n  <div class="thxCheckContainer">\n      <div class="thxCheckout">\n        <img src="/img/ThankYouPage.png" alt="thxCheck">\n      </div>\n   \n    <button align="center" id="thanks">Thank You</button>\n    \n  </div>') ];
}));

})();
