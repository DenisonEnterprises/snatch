/** Automatically generated file. DO NOT MODIFY */
package com.id1cnnem51qf7ik41ngag2r;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}