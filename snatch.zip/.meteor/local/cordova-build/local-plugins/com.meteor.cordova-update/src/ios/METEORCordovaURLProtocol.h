#import <Foundation/Foundation.h>

@interface METEORCordovaURLProtocol : NSURLProtocol

@end

